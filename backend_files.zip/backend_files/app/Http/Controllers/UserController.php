<?php

namespace App\Http\Controllers;

use App\Models\EventModel;
use App\Models\FavoritModel;
use App\Models\KritikSaranModel;
use App\Models\KuisionerModel;
use App\Models\LowonganModel;
use App\Models\TestimoniModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
}
