<div class="row mt-5">
    <?php if($info->isEmpty()): ?>
    <div class="col-sm-6 offset-sm-3 text-center">
        <img src="<?php echo e(asset('img/svg/ilustration/sad.svg')); ?>" width="350">
        <p class="my-3">Mohon maaf <i class="fas fa-cry"></i> kami belum punya data apapun</p>
    </div>
    <?php endif; ?>
    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-3">
        <div class="card border-0 p-4">
            <div id="carousel<?php echo e($row->id_info); ?>" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto1/' . $row->foto1 )); ?>"
                            class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto2/' . $row->foto2 )); ?>"
                            class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto3/' . $row->foto3 )); ?>"
                            class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carousel<?php echo e($row->id_info); ?>" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carousel<?php echo e($row->id_info); ?>" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
            <h4 class="my-3"><?php echo e($row->judul_info); ?></h4>
            <div class="card-body my-card-body p-0">
                <p><?php echo e($row->deskripsi); ?></p>
            </div>
            <button data-detail='<?php echo json_encode($row, 15, 512) ?>' data-bs-toggle="modal" data-bs-target="#detailModal" class="btn btn-selengkapnya bg-main text-white "><i
                class="fas fa-arrow-right"></i>
            Selengkapnya</button>
            <?php if(auth()->user()): ?>
            <?php if(isThisMyFavorit($row->id_info)): ?>
            <button data-id_info="<?php echo e($row->id_info); ?>" class="btn btn-light my-3 btn-hapus-favorit"><i class="text-danger fas fa-heart"></i> favorit anda</button>
            <?php else: ?>
            <button data-id_info="<?php echo e($row->id_info); ?>" class="btn btn-light my-3 btn-favorit"><i class="fas fa-heart"></i> tambah ke favorit</button>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH E:\PROJECT_DLL\yuk_cari_tahu\resources\views/pages/halaman_depan/card_info.blade.php ENDPATH**/ ?>