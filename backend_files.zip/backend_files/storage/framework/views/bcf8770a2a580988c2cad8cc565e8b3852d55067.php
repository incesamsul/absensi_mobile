<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah data musik</h4>
                </div>
                <div class="card-body">
                    <form id="formInfo" action="<?php echo e(URL::to('/admin/create_musik')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="judul_musik">judul_musik</label>
                            <input type="text" name="judul_musik" class="form-control" id="judul_musik">
                            <div id="errorMessage_judul_musik"></div>
                        </div>
                        <div class="form-group">
                            <label for="musik">musik</label>
                            <input type="file" accept=".mp3" name="musik" class="form-control" id="musik">
                            <div id="errorMessage_id_musik_youtube"></div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn bg-main text-white" id="btn-simpan-info">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $musik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6">
            <div class="card p-4">
                <audio controls>

                    <source src="<?php echo e($row->musik); ?>" type="audio/mp3">
                  Your browser does not support the audio element.
                  </audio>
                <h4 class="my-3"><?php echo e($row->judul); ?></h4>
                <div class="card-body my-card-body p-0">
                    <p><?php echo e($row->judul); ?></p>
                </div>
                <button data-id_musik="<?php echo e($row->id_musik); ?>" class="btn btn-danger hapus-info"><i
                        class="fas fa-trash"></i>
                    Delete</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let judul_musik = errorMessageDisplay('judul_musik');
        let musik = errorMessageDisplay('musik');

        if(judul_musik == 1 && musik== 1 ){
            $('#formInfo').submit();
        }

    })


    $('.hapus-info').on('click', function() {
            Swal.fire({
                title: 'Apakah yakin?'
                , text: "Data tidak bisa kembali lagi!"
                , type: 'warning'
                , showCancelButton: true
                , confirmButtonColor: '#3085d6'
                , cancelButtonColor: '#d33'
                , confirmButtonText: 'Ya, Konfirmasi'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                        , url: '/admin/delete_musik'
                        , method: 'post'
                        , dataType: 'json'
                        , data: {
                            id_musik: $(this).data('id_musik'),
                        }
                        , success: function(data) {
                            if (data == 1) {
                                Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                    location.reload();
                                });
                            }
                        }
                        , error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        });

    $('#liMusik').addClass('active');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/music/index.blade.php ENDPATH**/ ?>