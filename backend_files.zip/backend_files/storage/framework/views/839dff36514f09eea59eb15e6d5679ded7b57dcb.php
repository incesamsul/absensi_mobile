<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah soal essay</h4>
                </div>
                <div class="card-body">
                    <form id="formInfo" action="<?php echo e(URL::to('/admin/create_soal_essay')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="soal">soal</label>
                            <input type="hidden" name="id_soal_essay" class="form-control" id="id_soal_essay" value="<?php echo e($edit ? $edit->id_soal_essay : ''); ?>">
                            <input value="<?php echo e($edit ? $edit->soal : ''); ?>" type="text" name="soal" class="form-control" id="soal">
                            <div id="errorMessage_soal"></div>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn bg-main text-white" id="btn-simpan-info">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card p-4">
                <p><?php echo e($loop->iteration); ?>. <?php echo e($row->soal); ?></p>
                <a href="<?php echo e(URL::to('/admin/evaluasi_essay/' . $row->id_soal_essay )); ?>" class="btn btn-warning mb-3"><i class="fas fa-pen"></i>
                    Edit</a>
                <button data-id_data="<?php echo e($row->id_soal_essay); ?>" class="btn btn-danger hapus-info"><i class="fas fa-trash"></i>
                    Delete</button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let soal = errorMessageDisplay('soal');


        if (soal == 1 ) {
            $('#formInfo').submit();
        }

    })


    $('.hapus-info').on('click', function() {
        Swal.fire({
            title: 'Apakah yakin?',
            text: "Data tidak bisa kembali lagi!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Konfirmasi'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/admin/delete_soal_essay',
                    method: 'post',
                    dataType: 'json',
                    data: {
                        id_data: $(this).data('id_data'),
                    },
                    success: function(data) {
                        if (data == 1) {
                            Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                location.reload();
                            });
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }
                })
            }
        })
    });

    $('#livideo').addClass('active');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/evaluasi/essay.blade.php ENDPATH**/ ?>