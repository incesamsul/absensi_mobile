<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah soal</h4>
                </div>
                <div class="card-body">
                    <form id="formInfo" action="<?php echo e(URL::to('/admin/create_soal')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="soal">soal</label>
                            <input type="hidden" name="id_soal_evaluasi" class="form-control" id="id_soal_evaluasi" value="<?php echo e($edit ? $edit->id_soal_evaluasi : ''); ?>">
                            <input value="<?php echo e($edit ? $edit->soal : ''); ?>" type="text" name="soal" class="form-control" id="soal">
                            <div id="errorMessage_soal"></div>
                        </div>
                        <div class="form-group">
                            <label for="jawaban_a">jawaban_a</label>
                            <input value="<?php echo e($edit ? $edit->a : ''); ?>" type="text" name="jawaban_a" class="form-control" id="jawaban_a">
                            <div id="errorMessage_jawaban_a"></div>
                        </div>
                        <div class="form-group">
                            <label for="jawaban_b">jawaban_b</label>
                            <input value="<?php echo e($edit ? $edit->b : ''); ?>" type="text" name="jawaban_b" class="form-control" id="jawaban_b">
                            <div id="errorMessage_jawaban_b"></div>
                        </div>
                        <div class="form-group">
                            <label for="jawaban_c">jawaban_c</label>
                            <input value="<?php echo e($edit ? $edit->c : ''); ?>" type="text" name="jawaban_c" class="form-control" id="jawaban_c">
                            <div id="errorMessage_jawaban_c"></div>
                        </div>
                        <div class="form-group">
                            <label for="jawaban_d">jawaban_d</label>
                            <input value="<?php echo e($edit ? $edit->d : ''); ?>" type="text" name="jawaban_d" class="form-control" id="jawaban_d">
                            <div id="errorMessage_jawaban_d"></div>
                        </div>
                        <div class="form-group">
                            <label for="jawaban_benar">jawaban_benar</label>
                            <input value="<?php echo e($edit ? $edit->jawaban : ''); ?>" type="text" name="jawaban_benar" class="form-control" id="jawaban_benar">
                            <div id="errorMessage_jawaban_benar"></div>
                        </div>
                        <div class="form-group">
                            <label for="pembahasan">pembahasan</label>
                            <input value="<?php echo e($edit ? $edit->pembahasan : ''); ?>" type="text" name="pembahasan" class="form-control" id="pembahasan">
                            <div id="errorMessage_pembahasan"></div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn bg-main text-white" id="btn-simpan-info">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card p-4">
                <p><?php echo e($row->soal); ?></p>
                <ol type="a">
                    <li><?php echo e($row->a); ?></li>
                    <li><?php echo e($row->b); ?></li>
                    <li><?php echo e($row->c); ?></li>
                    <li><?php echo e($row->d); ?></li>
                </ol>
                <p class="text-success">jawaban benar : <?php echo e($row->jawaban); ?></p>
                <p class="text-warning">pembahasan : <?php echo e($row->pembahasan); ?></p>
                <a href="<?php echo e(URL::to('/admin/evaluasi/' . $row->id_soal_evaluasi . '/' . $row->id_info)); ?>" class="btn btn-warning mb-3"><i class="fas fa-pen"></i>
                    Edit</a>
                <button data-id_data="<?php echo e($row->id_soal_evaluasi); ?>" class="btn btn-danger hapus-info"><i class="fas fa-trash"></i>
                    Delete</button>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let soal = errorMessageDisplay('soal');
        let jawaban_a = errorMessageDisplay('jawaban_a');
        let jawaban_b = errorMessageDisplay('jawaban_b');
        let jawaban_c = errorMessageDisplay('jawaban_c');
        let jawaban_d = errorMessageDisplay('jawaban_d');
        let jawaban_benar = errorMessageDisplay('jawaban_benar');
        let pembahasan = errorMessageDisplay('pembahasan');

        if (soal == 1 && jawaban_a == 1 && jawaban_b == 1 && jawaban_c == 1 && jawaban_d == 1 && jawaban_benar == 1 && pembahasan == 1) {
            $('#formInfo').submit();
        }

    })


    $('.hapus-info').on('click', function() {
        Swal.fire({
            title: 'Apakah yakin?',
            text: "Data tidak bisa kembali lagi!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, Konfirmasi'
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/admin/delete_soal',
                    method: 'post',
                    dataType: 'json',
                    data: {
                        id_data: $(this).data('id_data'),
                    },
                    success: function(data) {
                        if (data == 1) {
                            Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                location.reload();
                            });
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }
                })
            }
        })
    });

    $('#livideo').addClass('active');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/evaluasi/index.blade.php ENDPATH**/ ?>