<?php $__env->startSection('content'); ?>
<section id="content">
    <div class="container">
        <div class="row text-center">
            <div class="col-sm-6 offset-sm-3">
                <h3 >Favorit</h3>
                <p>Temukan informasi favorit anda yang telah anda simpan sebelumnya.</p>
            </div>
        </div>
        <?php echo $__env->make('pages.halaman_depan.card_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>

<?php echo $__env->make('pages.halaman_depan.modal_warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.halaman_depan.modal_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('pages.halaman_depan.modal_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    $('.btn-selengkapnya').on('click',function(){
        console.log($(this).data('detail'))
        let detail = $(this).data('detail');
        $('#detailModalLabel').html(detail.judul_info);
        $('#judulInfoLabel').html(detail.judul_info);
        $('#deskripsiInfoLabel').html(detail.deskripsi);
        $('#gambar1').attr('src','data/data_upload/sejarah/' + removeSpace(detail.judul_info) + '/foto1/' + detail.foto1);
        $('#gambar2').attr('src','data/data_upload/sejarah/' + removeSpace(detail.judul_info) + '/foto2/' + detail.foto2);
        $('#gambar3').attr('src','data/data_upload/sejarah/' + removeSpace(detail.judul_info) + '/foto3/' + detail.foto3);

    })

</script>
<?php echo $__env->make('pages.halaman_depan.login_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.halaman_depan.script_tambah_favorit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.halaman_depan.script_hapus_favorit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_home.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT_DLL\file_yuk_cari_tahu\yuk_cari_tahu\resources\views/pages/halaman_depan/favorit.blade.php ENDPATH**/ ?>