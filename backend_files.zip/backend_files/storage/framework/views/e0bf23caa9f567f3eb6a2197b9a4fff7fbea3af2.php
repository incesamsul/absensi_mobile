<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah data <?php echo e($jenis_informasi); ?></h4>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('pages.info.form_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
            <div class="card p-4">
                <img src="<?php echo e(asset($row->foto1)); ?>"
                class="d-block w-100" alt="...">
                <h4 class="my-3"><?php echo e($row->judul_info); ?></h4>
                <div class="card-body my-card-body p-0">
                    <p><?php echo e($row->deskripsi); ?></p>
                </div>
                <button data-id_info="<?php echo e($row->id_info); ?>" class="btn btn-danger hapus-info"><i
                        class="fas fa-trash"></i>
                    Delete</button>
                    <a href="<?php echo e(URL::to('/admin/info/' . $row->id_kategori . '/' . $row->id_info)); ?>" class="btn btn-warning mt-3"><i
                        class="fas fa-pen"></i>
                    Edit</a>
                    <a href="<?php echo e(URL::to('/admin/sub_info/' . $row->id_info )); ?>" class="btn btn-primary mt-3"><i
                        class="fas fa-list"></i>
                    Sub info</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let dataEdit = $(this).data('edit');
        if(dataEdit.length == 0){
            let judul = errorMessageDisplay('judul');
            let foto1 = validateFotoDisplay('foto1');
            // let foto2 = validateFotoDisplay('foto2');
            // let foto3 = validateFotoDisplay('foto3');
            let deskripsi = errorMessageDisplay('deskripsi');

            // if(judul == 1 && foto1 == 1 && foto2 == 1 && foto3 == 1 && deskripsi == 1){
            if(judul == 1 && foto1 == 1 && deskripsi == 1){
                $('#formInfo').submit();
            }
        } else {
            let judul = errorMessageDisplay('judul');
            // let foto1 = validateFotoDisplay('foto1');
            // let foto2 = validateFotoDisplay('foto2');
            // let foto3 = validateFotoDisplay('foto3');
            let deskripsi = errorMessageDisplay('deskripsi');

            // if(judul == 1 && foto1 == 1 && foto2 == 1 && foto3 == 1 && deskripsi == 1){
            if(judul == 1 && deskripsi == 1){
                $('#formInfo').submit();
            }
        }

    })


    $('.hapus-info').on('click', function() {
            Swal.fire({
                title: 'Apakah yakin?'
                , text: "Data tidak bisa kembali lagi!"
                , type: 'warning'
                , showCancelButton: true
                , confirmButtonColor: '#3085d6'
                , cancelButtonColor: '#d33'
                , confirmButtonText: 'Ya, Konfirmasi'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                        , url: '/admin/hapus_info'
                        , method: 'post'
                        , dataType: 'json'
                        , data: {
                            id_info: $(this).data('id_info'),
                        }
                        , success: function(data) {
                            if (data == 1) {
                                Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                    location.reload();
                                });
                            }
                        }
                        , error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        });

    $('<?php echo e($info); ?>').addClass('active');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/info/main.blade.php ENDPATH**/ ?>