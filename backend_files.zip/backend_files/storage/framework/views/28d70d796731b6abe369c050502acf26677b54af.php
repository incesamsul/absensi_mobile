<form id="formInfo" action="<?php echo e(URL::to('/admin/simpan_info')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="judul">judul</label>
        <input type="hidden" name="id_info" value="<?php echo e($edit ? $edit->id_info :''); ?>">
        <input type="hidden" name="kategori" class="form-control" value="<?php echo e($id_kategori); ?>">
        <input type="text" name="judul" class="form-control" id="judul" value="<?php echo e($edit ? $edit->judul_info : ''); ?>">
        <div id="errorMessage_judul"></div>
    </div>

    <div class="form-group">
        <label for="foto1">Foto </label>
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="foto1" name="foto1">
            <label class="custom-file-label" for="foto1">Pilih
                File</label>
            <div id="errorMessage_foto1"></div>
        </div>
    </div>
    
    <div class="form-group">
        <label for="deskripsi">deskripsi</label>
        <textarea class="form-control" name="deskripsi" id="deskripsi" cols="30" rows="10"><?php echo e($edit ? $edit->deskripsi : ''); ?></textarea>
        <div id="errorMessage_deskripsi"></div>
    </div>
    <div class="form-group">
        <button data-edit='<?php echo json_encode($edit, 15, 512) ?>' type="submit" class="btn bg-main text-white" id="btn-simpan-info">Simpan</button>
    </div>
</form>
<?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/info/form_data.blade.php ENDPATH**/ ?>