<?php echo $__env->make('layouts.v_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.v_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.v_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Main Content -->
      <div class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
<?php echo $__env->make('layouts.v_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH E:\PROJECT_DLL\yuk_cari_tahu\resources\views/layouts/v_template.blade.php ENDPATH**/ ?>