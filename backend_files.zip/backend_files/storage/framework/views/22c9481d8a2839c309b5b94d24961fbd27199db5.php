
<?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($loop->iteration); ?></td>
    <td><?php echo e($p->name); ?></td>
    <td><?php echo e($p->email); ?></td>
    <td><?php echo e($p->role); ?></td>
    <td class="option">
        <div class="btn-group dropleft btn-option">
            <i type="button" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-ellipsis-v"></i>
            </i>
            <div class="dropdown-menu">
                
                <a data-pengguna='<?php echo json_encode($p, 15, 512) ?>' data-toggle="modal" data-target="#modalPengguna" class="dropdown-item edit" href="#"><i class="fas fa-pen"> Edit</i></a>
                <a data-id_pengguna="<?php echo e($p->id); ?>" class="dropdown-item hapus" href="#"><i class="fas fa-trash"> Hapus</i></a>
            </div>
        </div>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr class="no-hover">
    <td colspan="5" class="text-center">
        <br>
        <?php echo $pengguna->links('pagination::bootstrap-4'); ?>

    </td>
</tr>


<?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/pengguna/users_data.blade.php ENDPATH**/ ?>