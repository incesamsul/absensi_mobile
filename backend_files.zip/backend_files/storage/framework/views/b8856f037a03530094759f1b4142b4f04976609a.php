<form id="formInfo" action="<?php echo e(URL::to('/admin/simpan_info')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="judul">judul</label>
        <input type="hidden" name="kategori" class="form-control" value="<?php echo e($id_kategori); ?>">
        <input type="text" name="judul" class="form-control" id="judul">
        <div id="errorMessage_judul"></div>
    </div>

    <div class="form-group">
        <label for="foto1">Foto slide 1</label>
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="foto1" name="foto1">
            <label class="custom-file-label" for="foto1">Pilih
                File</label>
            <div id="errorMessage_foto1"></div>
        </div>
    </div>
    <div class="form-group">
        <label for="foto2">Foto slide 2</label>
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="foto2" name="foto2">
            <label class="custom-file-label" for="foto2">Pilih
                File</label>
            <div id="errorMessage_foto2"></div>
        </div>
    </div>
    <div class="form-group">
        <label for="foto3">Foto slide 3</label>
        <div class="custom-file">
            <input type="file" class="custom-file-input" id="foto3" name="foto3">
            <label class="custom-file-label" for="foto3">Pilih
                File</label>
            <div id="errorMessage_foto3"></div>
        </div>
    </div>
    <div class="form-group">
        <label for="deskripsi">deskripsi</label>
        <textarea class="form-control" name="deskripsi" id="deskripsi" cols="30" rows="10"></textarea>
        <div id="errorMessage_deskripsi"></div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-dark" id="btn-simpan-info">Simpan</button>
    </div>
</form>
<?php /**PATH E:\PROJECT_DLL\file_yuk_cari_tahu\yuk_cari_tahu\resources\views/pages/info/form_data.blade.php ENDPATH**/ ?>