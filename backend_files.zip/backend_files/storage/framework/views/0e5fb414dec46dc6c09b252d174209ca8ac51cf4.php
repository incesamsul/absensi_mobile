<!-- Modal -->
<div class="modal fade" id="warningModal" tabindex="-1" aria-labelledby="warningModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div class="container">
              <div class="row text-center">
                  <div class="col-sm-12">
                      <img src="<?php echo e(asset('img/svg/ilustration/sad.svg')); ?>" alt="" width="200">
                      <p class="my-4">Maaf anda harus login untuk bisa akses menu ini ...</p>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH E:\PROJECT_DLL\yuk_cari_tahu\resources\views/pages/halaman_depan/modal_warning.blade.php ENDPATH**/ ?>