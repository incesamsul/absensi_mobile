<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah data <?php echo e($jenis_informasi); ?></h4>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('pages.info.form_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3">
            <div class="card p-4">
                <div id="test<?php echo e($row->id_info); ?>" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto1/' . $row->foto1 )); ?>"
                                class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto2/' . $row->foto2 )); ?>"
                                class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('data/data_upload/sejarah/'. removeSpace($row->judul_info) . '/foto3/' . $row->foto3 )); ?>"
                                class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-target="#test<?php echo e($row->id_info); ?>"
                        data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-target="#test<?php echo e($row->id_info); ?>"
                        data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </button>
                </div>
                <h4 class="my-3"><?php echo e($row->judul_info); ?></h4>
                <div class="card-body my-card-body p-0">
                    <p><?php echo e($row->deskripsi); ?></p>
                </div>
                <button data-id_info="<?php echo e($row->id_info); ?>" class="btn btn-danger hapus-info"><i
                        class="fas fa-trash"></i>
                    Delete</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let judul = errorMessageDisplay('judul');
        let foto1 = validateFotoDisplay('foto1');
        let foto2 = validateFotoDisplay('foto2');
        let foto3 = validateFotoDisplay('foto3');
        let deskripsi = errorMessageDisplay('deskripsi');

        if(judul == 1 && foto1 == 1 && foto2 == 1 && foto3 == 1 && deskripsi == 1){
            $('#formInfo').submit();
        }

    })


    $('.hapus-info').on('click', function() {
            Swal.fire({
                title: 'Apakah yakin?'
                , text: "Data tidak bisa kembali lagi!"
                , type: 'warning'
                , showCancelButton: true
                , confirmButtonColor: '#3085d6'
                , cancelButtonColor: '#d33'
                , confirmButtonText: 'Ya, Konfirmasi'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                        , url: '/admin/hapus_info'
                        , method: 'post'
                        , dataType: 'json'
                        , data: {
                            id_info: $(this).data('id_info'),
                        }
                        , success: function(data) {
                            if (data == 1) {
                                Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                    location.reload();
                                });
                            }
                        }
                        , error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        });

    $('#liSejarah').addClass('active');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT_DLL\file_yuk_cari_tahu\yuk_cari_tahu\resources\views/pages/info/sejarah.blade.php ENDPATH**/ ?>