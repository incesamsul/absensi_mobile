 <!-- Modal -->
 <div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="detailModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="detailModalBody">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img id="gambar1" src=""
                            class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img id="gambar2" src=""
                            class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img id="gambar3" src=""
                            class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
            <h4 class="my-3" id="judulInfoLabel">gagal meload data...</h4>
            <div class="card-body  p-0" id="deskripsiInfoLabel">
                gagal meload data ....
            </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH E:\PROJECT_DLL\yuk_cari_tahu\resources\views/pages/halaman_depan/modal_detail.blade.php ENDPATH**/ ?>