<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tambah data video</h4>
                </div>
                <div class="card-body">
                    <form id="formInfo" action="<?php echo e(URL::to('/admin/create_video')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="judul_video">judul_video</label>
                            <input type="text" name="judul_video" class="form-control" id="judul_video">
                            <div id="errorMessage_judul_video"></div>
                        </div>
                        <div class="form-group">
                            <label for="kategori">kategori</label>
                            <select name="kategori" id="kategori" class="form-control">
                                <option>tari</option>
                                <option>pembelajaran</option>
                            </select>
                            <div id="errorMessage_kategori"></div>
                        </div>
                        <div class="form-group">
                            <label for="id_video_youtube">id_video_youtube</label>
                            <input type="text" name="id_video_youtube" class="form-control" id="id_video_youtube">
                            <div id="errorMessage_id_video_youtube"></div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn bg-main text-white" id="btn-simpan-info">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6">
            <div class="card p-4">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($row->id_video_youtube); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <h4 class="my-3"><?php echo e($row->judul_video); ?></h4>
                <div class="card-body p-0">
                    <p>Kategori : <span class="badge badge-info"><?php echo e($row->kategori); ?></span></p>
                </div>
                <button data-id_video="<?php echo e($row->id_video); ?>" class="btn btn-danger hapus-info"><i
                        class="fas fa-trash"></i>
                    Delete</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('#btn-simpan-info').on('click', function(e) {
        e.preventDefault();
        let judul_video = errorMessageDisplay('judul_video');
        let id_video_youtube = errorMessageDisplay('id_video_youtube');
        let kategori = errorMessageDisplay('kategori');

        if(judul_video == 1 && id_video_youtube== 1 && kategori ==1){
            $('#formInfo').submit();
        }

    })


    $('.hapus-info').on('click', function() {
            Swal.fire({
                title: 'Apakah yakin?'
                , text: "Data tidak bisa kembali lagi!"
                , type: 'warning'
                , showCancelButton: true
                , confirmButtonColor: '#3085d6'
                , cancelButtonColor: '#d33'
                , confirmButtonText: 'Ya, Konfirmasi'
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                        , url: '/admin/delete_video'
                        , method: 'post'
                        , dataType: 'json'
                        , data: {
                            id_video: $(this).data('id_video'),
                        }
                        , success: function(data) {
                            if (data == 1) {
                                Swal.fire('Berhasil', 'Data telah terhapus', 'success').then((result) => {
                                    location.reload();
                                });
                            }
                        }
                        , error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        });

    $('#livideo').addClass('active');

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/pages/video/index.blade.php ENDPATH**/ ?>