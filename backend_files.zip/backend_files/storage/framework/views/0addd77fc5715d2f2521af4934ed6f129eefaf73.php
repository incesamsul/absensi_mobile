<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">App edukasi</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">St</a>
        </div>
        <ul class="sidebar-menu">

            
            
            <li class="menu-header">Pengguna</li>
            <li class="" id="liDashboard"><a class="nav-link" href="<?php echo e(URL::to('/dashboard')); ?>"><i
                        class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
            <li class="" id="liProfile"><a class="nav-link" href="<?php echo e(URL::to('/profile')); ?>"><i class="fas fa-user"></i>
                    <span>Profile</span></a></li>
            <li class="" id="liBantuan"><a class="nav-link" href="<?php echo e(URL::to('/bantuan')); ?>"><i
                        class="fas fa-question-circle"></i> <span>Bantuan</span></a></li>



            <?php if(auth()->user()->role == 'admin'): ?>
            
            <li class="menu-header">Admin</li>
            <li class="nav-item dropdown " id="liPengguna">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-users"></i>
                    <span>Pengguna</span></a>
                <ul class="dropdown-menu">
                    <li id="liManajemenPengguna"><a class="nav-link" href="/admin/pengguna">Manajemen Pengguna</a></li>
                </ul>
            </li>

            

            
            
            <?php endif; ?>

            <?php if(auth()->user()->role == 'guru'): ?>
            
            <li class="menu-header">Guru</li>

            <li class="" id="liVideo"><a class="nav-link" href="<?php echo e(URL::to('/admin/video')); ?>"><i
                class="fab fa-youtube"></i> <span>Video</span></a></li>
            <li class="" id="liMusik"><a class="nav-link" href="<?php echo e(URL::to('/admin/musik')); ?>"><i
                class="fas fa-music"></i> <span>Msuik</span></a></li>

            <li class="" id="liKategori"><a class="nav-link" href="<?php echo e(URL::to('/admin/kategori')); ?>"><i
                        class="fas fa-list-alt"></i> <span>Kategori</span></a></li>

            <li class="" id="liEvaluasi"><a class="nav-link" href="<?php echo e(URL::to('/admin/evaluasi')); ?>"><i
                        class="fas fa-question"></i> <span>Evaluasi</span></a></li>

            <li class="" id="liEvaluasiEssay"><a class="nav-link" href="<?php echo e(URL::to('/admin/evaluasi_essay')); ?>"><i
                        class="fas fa-question"></i> <span>Evaluasi Essay</span></a></li>


            <?php $__currentLoopData = getKategoriMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="" id="liSejarah"><a class="nav-link" href="<?php echo e(URL::to('/admin/info/' . $row->id_kategori)); ?>"><i
                class="fas fa-chevron-circle-right"></i> <span><?php echo e($row->nama_kategori); ?></span></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php endif; ?>







        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
            <a href="<?php echo e(URL::to('/logout')); ?>" class="btn bg-main text-white btn-lg btn-block btn-icon-split">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </aside>
</div>
<?php /**PATH D:\PROJECT\MOBILE\backend_files\resources\views/layouts/v_sidebar.blade.php ENDPATH**/ ?>